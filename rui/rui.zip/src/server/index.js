var express=require('express');
var app=express();
var mysql=require('mysql');
var path=require("path");
var bo=require("body-parser");
var bodys=bo.urlencoded({extended:false})
var a=mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"root",
    // password:"123",
    database:'1601n'
})
app.all("*",(req,res,next)=>{
    res.header('Access-Control-Allow-Origin', '*');
    next()
})
app.get("/login",function(req,res){
    a.query("select * from user where username=? and password=?",[req.query.user,req.query.pass],function(err,result){
        if(err){
            res.send({code:1,mgs:"服务器出现错误"})
        }
        else{
            if(result.length>0){
                res.send({code:2,mgs:"Login Successful"})
            }
            else{
                res.send({code:0,mgs:"Please reenter your account or password error!!!"})          
            }
        }
    })
})
app.get("/deng",function(req,res){
    a.query("select username from user where username=?",[req.query.user],function(err,result){
        if(err){
            res.send({code:1,mgs:"服务器出现错误"})
        }
        else{
            if(result.length>0){
                res.send({code:2,mgs:"The account already exists, please reselect the username"})
            }
            else{
                a.query("insert into user(username,password) values(?,?)",[req.query.user,req.query.pass],function(err,result){
                    if(err){
                        res.send({code:1,mgs:"服务器出现错误"})
                    }
                    else{
                        res.send({code:0,mgs:"Congratulations, the registration is successful, you can log in directly"})
                    }
                })
            }
        }
    })
})
app.listen(8098,function(){
    console.log("服务启动成功")
})