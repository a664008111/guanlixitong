<template>
  <div class="box">
    <el-container>
      <el-header><p><img src="../../static/1.gif" alt=""></p><marquee class="mar" width="340" height="60" onMouseOut="this.start()" onMouseOver="this.stop()"><h1>欢迎来到160N班后台管理系统</h1> 欢迎来到160N班</marquee></el-header> 
      <el-container style="height: 500px; border: 1px solid #eee">
        <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
          <el-menu :default-openeds="['1', '3']">
             <el-menu-item index="0">
               <el-tooltip class="item" effect="dark" content="高级用户" placement="right">
                 <el-button><p><img src="../../static/77.png" alt=""></p>当前用户：<span style="color:red"> {{user}}</span></el-button>
               </el-tooltip>
              </el-menu-item>
            <el-submenu index="1"> 
              <template slot="title"><i class="el-icon-message"></i>导航一</template>         
                <router-link to="/helloWorld/he_home"><el-menu-item index="1-1">选项1</el-menu-item></router-link>
                <el-menu-item index="1-2">选项2</el-menu-item>
            </el-submenu>
            <el-submenu index="2">
              <template slot="title"><i class="el-icon-menu"></i>导航二</template>
                <el-menu-item index="2-1">选项1</el-menu-item>
                <el-menu-item index="2-2">选项2</el-menu-item>
            </el-submenu>
            <el-submenu index="3">
              <template slot="title"><i class="el-icon-setting"></i>导航三</template>
                <el-menu-item index="3-1">选项1</el-menu-item>
                <el-menu-item index="3-2">选项2</el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
         <el-container>
            <el-main>
            <router-view></router-view>
            </el-main>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
    data(){
      return {
         user:''
      }
    },
    methods:{
        init(){
           this.user=sessionStorage.getItem("user")
        }
    },
    mounted(){
      this.init()
    }
}
</script>

<style>
*{
  padding: 0;
  margin: 0;
  list-style-type: none;
  text-decoration: none;
}
.box{
  width: 100%;
  height: 100%;
}
.el-header, .el-footer {
    background-color: #fff; 
    color: #000;
    line-height: 60px;
    cursor: pointer;
  }
  .mar{
    flex:1;
  }
  .el-header{
    /* background: url("../../static/1.png") no-repeat center center;
    background-size: cover; */
    display: flex;
    justify-content: space-between;
  }
  .el-header p{
    position: relative;
    flex-basis:180px;
    height: 60px;
    overflow: hidden;
  }
  .el-header p img{
    width: 150px;
    position: absolute;
    left: 0;
    top:-10px;
  }
  .el-aside {
    background-color: #ccc;
    color: #333;
    text-align: center;
    line-height: 200px;
  }
  .el-main {
    background-color: #fff;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
  .el-button p{
    width: 30px;
    height: 30px;
  }
  .el-menu-item{
    height: 80px;
  }
  .el-menu-item .el-button{
    border:none;
    margin: 0;
  }
  .el-button p img{
    width: 100%;
  }
</style>

