<template>
  <div class="login">
    <h1>
      <span><b>IT </b>Satellite</span>
      <ul>
        <li><el-button type="success" round>Administrator Login</el-button></li>
        <li><el-button type="success" round>British Council</el-button></li>
      </ul>
    </h1>
    <div class="center">
      <form action="/login">
        <h2>Supervising <span style="color:green;font-size:40px;padding:0 16px">System</span>  </h2>
        <li><el-input placeholder="Please enter the account number" v-model="user" clearable></el-input></li>
        <li><el-input placeholder="Please input a password" type="password" v-model="pass" clearable></el-input></li> 
        <li><el-button type="success" plain @click="opens">Register</el-button><el-button type="primary" plain @click="open">Login</el-button></li>
      </form>
    </div>  
  </div>
</template>

<script>
import axios from "axios";
export default {
      data(){
        return{
          user:'',
          pass:''
        }
      },
      methods:{
          open(){
            if(this.user==""||this.pass==""){
              this.$alert('Please enter an account or password', {
                      confirmButtonText: '确定',
                  });
            }else{
              axios.get("http://localhost:8098/login",{
                params:{
                  user:this.user,
                  pass:this.pass
                }
              }).then(res=>{
                console.log(res.data)
                    this.$alert(res.data.mgs, {
                      confirmButtonText: '确定',
                  });
                  if(res.data.code==2){
                    sessionStorage.setItem("user",this.user)
                    setTimeout(()=>{
                    window.open("http://169.254.115.222:8080/#/helloWorld","_self")
                    },2000)
                  }else{
                    this.$alert(res.data.mgs, {
                      confirmButtonText: '确定',
                  });
                  }
                  
                  
              })
              }
          },
          opens(){
            if(this.user==""||this.pass==""){
              this.$alert('The content can not be empty', {
                      confirmButtonText: '确定',
                  });
            }else if(this.user.length>=2){
              if(this.pass.length>=5){
                axios.get("http://localhost:8098/deng",{
                params:{
                  user:this.user,
                  pass:this.pass
                }
              }).then(res=>{
                    this.$alert(res.data.mgs, {
                      confirmButtonText: '确定',
                  });
              })
              }else{
                  this.$alert('The password must be more than five bits', {
                      confirmButtonText: '确定',
                  });
              }   
            }else{
                this.$alert('The account must be more than three', {
                      confirmButtonText: '确定',
                  });
              }     
          }
      },
      mounted(){

      }
}
</script>

<style>
body{
  width: 100%;
  height: 100%;
}
#app{
  width: 100%;
  height: 100%;
}
*{
  padding: 0;
  margin: 0;
  list-style-type: none;
  text-decoration: none;
}
.login{
    width: 100%;
    height: 630px;
    background: url("../../static/11.jpg") no-repeat center;
    background-size:cover; 
}
.el-input{
  width: 300px;
}
.login h1{
  width: 100%;
  height: 70px;
  line-height: 50px;
  background: rgba(255,255,255,.3);
  display: flex;
  justify-content: space-between;
}
.login h1 span b{
    color:green;
}
.login h1>span{
  margin-left:80px; 
  line-height: 70px;
}
.login h1 ul{
  display: flex;
  justify-content: space-between;
}
.login h1 ul li{
  margin: 0 40px;
}
.center{
  width: 30%;
  height: 350px;
  border:1px solid #ccc;
  box-shadow: 1px 2px 3px #ccc;
  border-radius: 10px;
  position: absolute;
  right:30px;
  top:25%;
  background: rgba(255,255,255,.2);
}
.center form{
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}
.center form li{
  width: 100%;
  text-align: center;
  
}
.center form h2{
  width: 100%;
  font-style: italic;
  text-align: center;
  cursor: pointer;
  color:#fff;
  margin: 46px 0;
}
.center form h2:hover{
    transition: all 1s;
    transform: rotateY(360deg)
}
.center form li:nth-child(2){
  padding-top: 0px;
  padding-bottom: 10px;
}
.center .el-button{
  width:37%;
  margin:20px; 
}
.el-message-box__content{
  text-align: center;
}
.el-message-box__btns{
   text-align: left;
   padding: 15px 60px 0;
}
.el-message-box__btns .el-button{
  width: 300px;
}
.el-button+.el-button{
  margin-left:0; 
}
.el-input{
  width: 80%;
}
</style>
